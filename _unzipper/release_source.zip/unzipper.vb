﻿Imports System.IO
Imports System.IO.Compression
Imports System.Text.RegularExpressions

' every code made by xBidoof#8159
' discord: https://discord.io/zoof

Public Class unzipper
    Dim arguments As String = ""

    Dim name_zip As String = ""
    Dim name_process As String = ""
    Dim name_executable As String = ""
    Dim name_software As String = ""
    Private Sub unzipper_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        For Each arg As String In My.Application.CommandLineArgs
            If arguments <> "" Then arguments &= " "
            arguments &= "" & arg & ""
        Next
        name_zip = CustomRegex("(?<=-zip_decompress ').+?(?=')", arguments)
        name_process = CustomRegex("(?<=-process_name ').+?(?=')", arguments)
        name_executable = CustomRegex("(?<=-process_start ').+?(?=')", arguments)
        name_software = CustomRegex("(?<=-soft_name ').+?(?=')", arguments)
        Threading.Thread.Sleep(200)
        ProcessZIpper()
    End Sub

    Private count_try As Short = 0
    Private Sub ProcessZIpper()
        If File.Exists(Application.StartupPath & "\" & name_zip) Then
            If name_process = "" Then
                ExtractZip()
            Else
GoExtract:
                Dim get_process_target As Process() = Process.GetProcessesByName(name_process)
                If get_process_target.Length = 0 Then
                    ExtractZip()
                Else
                    If count_try >= 10 Then
                        If MessageBox.Show("extraction of the update did not take place, the target process is still running, do you want to try again ?", "Update Warning", MessageBoxButtons.RetryCancel, MessageBoxIcon.Exclamation) = DialogResult.Retry Then
                            count_try = 0
                            GoTo GoExtract
                        Else
                            Close()
                        End If
                    End If
                    count_try += 1
                    Threading.Thread.Sleep(800)
                    GoTo GoExtract
                End If
            End If
        Else
            Close()
        End If
    End Sub

    Private Sub ExtractZip()
        Try
            Using archive = ZipFile.OpenRead(Application.StartupPath & "\" & name_zip)
                archive.ExtractToDirectory(Application.StartupPath, True)
            End Using
        Catch ex As Exception
            MessageBox.Show("Failed to install update for " & name_software, "Update Error", MessageBoxButtons.OK, MessageBoxIcon.Error)
            Close()
            Exit Sub
        End Try
        Threading.Thread.Sleep(200)
        File.Delete(Application.StartupPath & "\" & name_zip)
        Try
            Process.Start(Application.StartupPath & "\" & name_executable)
        Catch : End Try
        Close()
    End Sub
    Private Function CustomRegex(regex_string As String, content As String)
        Dim rx As New Regex(regex_string)
        Return rx.Match(content).Value
    End Function
End Class
